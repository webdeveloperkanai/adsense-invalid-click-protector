<?php
/**
 * @package location_manager
 * @version 1.4.3
 */
/*
Plugin Name: CPC Manager Free
Plugin URI: https://devsecit.com/
Description: This plugin allows that cuntries only who will give high CPC on google adsense. If you have google adsense then try it either don't activate. Use Luxembourg location after activate plugin. Inspired by <a href='https://cehpoint.co.in'>Mr. Jit Banarjee</a>. <strong>Contact </strong> <a href='https://wa.me/918101979855?text=CPC_WP'> on whatsapp</a>  <a href="https://devsecit.com/plugins/"><strong>Upgrade to premium</strong></a> 
Author: Kanai Shil
Version: 1.4.3
Author URI: https://ksconsultant.online
*/
 
    
    $version = '1.4.3'; 

    $ch = curl_init(); 
	$url = str_replace(" ","+","https://ksconsultant.online/verify/v/$version");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HEADER, 0); 
    $res = curl_exec($ch); 
    curl_close($ch);
    $data = json_decode($res, 1); 
    if($data['status']=='Yes') {
        $host = $_SERVER['HTTP_HOST']; 
        $ch = curl_init(); 
    	$url = str_replace(" ","+","https://ksconsultant.online/verify/plugin/$host");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0); 
        $res = curl_exec($ch); 
        curl_close($ch);
        $data = json_decode($res, 1);
        
        if ($data[0]['status']) {
             
            $url = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
            
            if(strpos($url,'wp-admin') !== false) {
                setcookie("login","true",time()+86400*1,"/"); 
            } else {}
            
             
            $ip = $_SERVER['REMOTE_ADDR'];   
            $curl = curl_init("https://ksconsultant.online/verify/country/$host/$ip");
            curl_setopt($curl, CURLOPT_FAILONERROR, true);
            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);  
            $result = curl_exec($curl);
            $res = json_decode($result, true);  
            $country = $res['country']; 
                if(isset($_COOKIE['ip'])) {
                    if($_COOKIE['ip']==$ip) {
                        if(isset($_COOKIE['visit'])) {
                            if($_COOKIE['visit']>5) { 
                                setcookie('visit',$_COOKIE['visit']+1,time()+900,"/"); 
                            } else {
                                setcookie('visit',$_COOKIE['visit']+1,time()+900,"/"); 
                            }
                        } else {
                            setcookie('visit','1',time()+900,'/');
                        }
                    } else {
                        setcookie('ip',$ip,time()+86400,"/"); 
                        setcookie('visit','1',time()+900,'/');
                    }
                } else {
                    setcookie('ip',$ip,time()+86400,"/"); 
                }
                // 3rd time curl   
                $ch = curl_init(); 
            	$url = str_replace(" ","+","https://ksconsultant.online/verify/country/$host/$ip");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_HEADER, 0); 
                $res = curl_exec($ch); 
                curl_close($ch);
                $data = json_decode($res, 1); 
                if($data['status']=='Yes') {}  ?>
            <div class="locationInfo" id="locationInfo" onclick="window.open('https://devsecit.com')">
                <h4> DEV SEC IT PVT. LTD. </h4>
            </div>

            <div class="locationInfoCountry" id="locationInfoCountry">
                <big> <?= $country ?> <br> <small> <?= $ip ?> </small> </big>
            </div>
            <style>
                .locationInfo {
                    position: fixed;
                    left: 30px;
                    bottom: 30px;
                    font-size: 14px;
                    color: antiquewhite;
                    background: lightblue;
                    padding: 5px 20px;
                    border-radius: 15px;
                    z-index: 9999999;
                    cursor: pointer color:white;
                }

                .locationInfoCountry {
                    position: fixed;
                    right: 30px;
                    top: 80px;
                    font-size: 16px;
                    color: antiquewhite;
                    background: lightgreen;
                    padding: 5px 20px;
                    border-radius: 25px;
                    z-index: 9999999;
                    cursor: pointer
                }

            </style> 
            <?php  
                    } else {
                        ?>
            <div class="locationInfo" id="locationInfo" onclick="window.open('https://wa.me/918101979855?text=CPC_WP')">
                <big> Your plugin is not acivated! Please contact with help center and activate your plugin. </big>
            </div>

            <style>
                .locationInfo {
                    position: fixed;
                    right: 30px;
                    bottom: 80px;
                    font-size: 14px;
                    color: antiquewhite;
                    background: lightblue;
                    padding: 5px 20px;
                    border-radius: 15px;
                    z-index: 9999999;
                    cursor: pointer color:white;
                }

            </style>

            <?php }
        
    } else { // update checking -->>> 
            ?>
            <div class="locationInfo" id="locationInfo" onclick="window.open('https://wa.me/918101979855?text=CPC_WP')">
                <big> Your plugin is not updated! Please contact with help center and update your plugin. </big>
            </div>

            <style>
                .locationInfo {
                    position: fixed;
                    right: 30px;
                    bottom: 80px;
                    font-size: 14px;
                    color: antiquewhite;
                    background: lightblue;
                    padding: 5px 20px;
                    border-radius: 15px;
                    z-index: 9999999;
                    cursor: pointer color:white;
                }

            </style>
            <?php 
        }  
?>
